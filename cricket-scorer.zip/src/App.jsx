import React from 'react';
import { CricketProvider, useCricket } from './context/CricketContext';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import DrawerMenu from './components/DrawerMenu';

// Screens
import AuthScreen from './components/screens/AuthScreen';
import MatchesScreen from './components/screens/MatchesScreen';
import MatchSetupScreen from './components/screens/MatchSetupScreen';
import ScoringScreen from './components/screens/ScoringScreen';
import ScorecardScreen from './components/screens/ScorecardScreen';
import MatchOverviewScreen from './components/screens/MatchOverviewScreen';
import InningsBreakScreen from './components/screens/InningsBreakScreen';
import MatchResultScreen from './components/screens/MatchResultScreen';
import ScoutingHubScreen from './components/screens/ScoutingHubScreen';
import PlayerProfileScreen from './components/screens/PlayerProfileScreen';
import PlayerRegistrationScreen from './components/screens/PlayerRegistrationScreen';
import PlayerComparisonModal from './components/screens/PlayerComparisonModal';

function MainApp() {
  const { currentScreen } = useCricket();

  const renderActiveScreen = () => {
    switch (currentScreen) {
      case 'welcome':
        return <AuthScreen />;
      case 'matches':
        return <MatchesScreen />;
      case 'match-setup':
        return <MatchSetupScreen />;
      case 'scoring':
        return <ScoringScreen />;
      case 'scorecard':
        return <ScorecardScreen />;
      case 'match-overview':
        return <MatchOverviewScreen />;
      case 'innings-break':
        return <InningsBreakScreen />;
      case 'match-result':
        return <MatchResultScreen />;
      case 'scouting':
        return <ScoutingHubScreen />;
      case 'player-profile':
        return <PlayerProfileScreen />;
      case 'player-registration':
        return <PlayerRegistrationScreen />;
      default:
        return <MatchesScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900 selection:bg-blue-500 selection:text-white">
      {/* Top App Header */}
      <Header />

      {/* Main Screen Content Area */}
      <main className="flex-1 w-full max-w-xl mx-auto">
        {renderActiveScreen()}
      </main>

      {/* Persistent Bottom Tab Navigation */}
      <BottomNav />

      {/* Side Drawer Navigation Menu */}
      <DrawerMenu />

      {/* Head-to-Head Comparison Modal */}
      <PlayerComparisonModal />
    </div>
  );
}

export default function App() {
  return (
    <CricketProvider>
      <MainApp />
    </CricketProvider>
  );
}
